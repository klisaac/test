using System;

namespace ToDo
{
    public class ToDo
    {
        public string Title { get; set; }

        public bool IsCompleted { get; set; }
    }
}
