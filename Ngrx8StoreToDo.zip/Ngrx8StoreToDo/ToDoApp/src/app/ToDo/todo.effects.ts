import { Injectable } from '@angular/core';
import { Actions, Effect, createEffect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of, pipe } from 'rxjs';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
// import { ToDoAction,ToDoActionTypes, SuccessGetToDoAction, ErrorToDoAction, BeginCreateToDoAction, SuccessCreateToDoAction } from './todo.action';
import * as ToDoActions from './todo.action';
import { ToDoHttpService } from './todo.httpservice';
import {IToDo} from './todo.model';

@Injectable()
export class ToDoEffects {
  constructor(private todoService: ToDoHttpService, private actions: Actions) {}
  todo: IToDo = { title:"Test", isCompleted:false};

  @Effect()
  GetToDos$ = this.actions.pipe(
    ofType<ToDoActions.BeginGetToDoAction>(ToDoActions.ToDoActionTypes.BeginGetToDoAction),
    switchMap(() => {
      return this.todoService.getToDos().pipe(
        map(data => new ToDoActions.SuccessGetToDoAction({ toDos: data })),
        catchError(error =>
          of(new ToDoActions.ErrorToDoAction({ error: error }))
        )
      );
    })
  );

  @Effect()
  CreateToDos$: Observable<Action> = this.actions
    .pipe(
      ofType<ToDoActions.BeginCreateToDoAction>(ToDoActions.ToDoActionTypes.BeginCreateToDoAction),
      mergeMap((action) => this.todoService.createToDos(action.payload.toDo)
      .pipe(
        map(data => {
          return (new ToDoActions.SuccessCreateToDoAction({toDo: data}));
        }),
        catchError((error) => of(new ToDoActions.ErrorToDoAction({error: error})))
      ))
  );

}