import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {IToDo} from './todo.model';

@Injectable()
export class ToDoHttpService {
  private ApiURL: string = 'https://localhost:44309/toDo';
  constructor(private httpclient: HttpClient) {}

  getToDos(): Observable<IToDo[]> {
    return this.httpclient.get<IToDo[]>(this.ApiURL);
  }

  createToDos(payload: IToDo): Observable<IToDo> {
    return this.httpclient.post<IToDo>(this.ApiURL, JSON.stringify(payload), {
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
