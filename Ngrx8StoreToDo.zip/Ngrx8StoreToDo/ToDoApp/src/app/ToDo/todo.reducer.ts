import { ActionReducerMap, MetaReducer, Action } from '@ngrx/store';
import {ToDoActionTypes, ActionsUnion} from './todo.action';
// import {IToDo} from './todo.model';
import ToDoState, { initializeToDoState } from './todo.state';

const initialState = initializeToDoState();

export function ToDoReducer(state: ToDoState = initialState, action: ActionsUnion): ToDoState {
  switch (action.type) {
    // case ToDoActionTypes.GetToDoAction:
    //   return { ...state, toDos: [...state.toDos], toDoError: null };

    //   case ToDoActionTypes.CreateToDoAction:
    //   // return {
    //   //   toDo: action.payload.toDo,
    //   //   toDoError: null
    //   // };
    //   return { ...state, toDos: [...state.toDos, action.payload.toDo], toDoError: null };
    
      case ToDoActionTypes.SuccessGetToDoAction:
        return {  ...state, toDos: action.payload.toDos, toDoError: null  };
      
        case ToDoActionTypes.SuccessCreateToDoAction:
          return { ...state, toDos: [...state.toDos, action.payload.toDo], toDoError: null };

    case ToDoActionTypes.ErrorToDoAction:
      return {
        toDos: null,
        toDoError: action.payload.error
      };

    default:
      return state;
  }
}

export const selectToDos = (state: ToDoState) => state.toDos;