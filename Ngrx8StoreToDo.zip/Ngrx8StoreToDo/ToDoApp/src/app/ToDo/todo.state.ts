import {IToDo} from './todo.model';

export default class ToDoState {
  toDos: IToDo[];
  toDoError: Error;
}

export const initializeToDoState = (): ToDoState => {
  return { toDos:[], toDoError: null };
};
