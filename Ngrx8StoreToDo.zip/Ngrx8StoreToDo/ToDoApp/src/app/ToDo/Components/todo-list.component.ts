import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import * as ToDoActions from '../todo.action';
import {IToDo} from '../todo.model';
import ToDoState from '../todo.state';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  todo: Observable<ToDoState>;
  ToDoSubscription: Subscription;
  ToDoList: IToDo[] = [];

  title: string = '';
  isCompleted: boolean = false;

  todoError: Error = null;
  
  constructor(private store: Store<{ todos: ToDoState }>) {
    this.todo = store.pipe(select('todos'));
  }

  ngOnInit() {
    this.ToDoSubscription = this.todo
      .pipe(
        map(x => {
          this.ToDoList = x.toDos;
          this.todoError = x.toDoError;
        })
      )
      .subscribe();

    this.store.dispatch(new ToDoActions.BeginGetToDoAction());
  }

  ngOnDestroy() {
    if (this.ToDoSubscription) {
      this.ToDoSubscription.unsubscribe();
    }
  }

}
