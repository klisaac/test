import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import * as ToDoActions from '../todo.action';
import {IToDo} from '../todo.model';
import ToDoState from '../todo.state';

@Component({
  selector: 'app-to-do',
  templateUrl: './to-do.component.html',
  styleUrls: ['./to-do.component.css']
})
export class ToDoComponent implements OnInit {
  
  todo: Observable<ToDoState>;
  toDoSubscription: Subscription;
  toDoList: IToDo[] = [];
  todoError: Error = null;
  title: string = '';
  isCompleted: boolean = false;

  constructor(private store: Store<{ todos: ToDoState }>) {
    this.todo = store.pipe(select('todos'));
  }

  ngOnInit() {
    this.toDoSubscription = this.todo
      .pipe(
        map(x => {
          this.toDoList = x.toDos;
          this.todoError = x.toDoError;
        })
      )
      .subscribe();
  }


  createToDo() {
    const todo: IToDo = { title: this.title, isCompleted: this.isCompleted };
    this.store.dispatch(new ToDoActions.BeginCreateToDoAction({ toDo: todo }));
    this.title = '';
    this.isCompleted = false;
  }
  ngOnDestroy() {
    if (this.toDoSubscription) {
      this.toDoSubscription.unsubscribe();
    }
  }

}
