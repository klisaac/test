import {Action} from '@ngrx/store';
import {IToDo} from './todo.model';

export enum ToDoActionTypes {
  GetToDoAction = '[ToDo] - Get ToDo',
  CreateToDoAction = '[ToDo] - Create ToDo',
  BeginGetToDoAction = '[ToDo] - Begin Get ToDo',
  SuccessGetToDoAction = '[ToDo] - Sucess Get ToDo',
  BeginCreateToDoAction ='[ToDo] - Begin Create ToDo',
  SuccessCreateToDoAction = '[ToDo] - Sucess Create ToDo',
  ErrorToDoAction = '[ToDo] - Error'
}

// export class ToDoAction implements Action {
//   type: string;
//   payload: {
//     toDo: IToDo
//   };
// }

// export class GetToDoAction implements Action {
//   readonly type = ToDoActionTypes.GetToDoAction;
// };

// export class CreateToDoAction implements Action {
//   readonly type = ToDoActionTypes.CreateToDoAction;
//   constructor(readonly payload: {toDo: IToDo}) {}
// };

export class BeginGetToDoAction implements Action {
  readonly type = ToDoActionTypes.BeginGetToDoAction;
};

export class SuccessGetToDoAction implements Action {
  readonly type = ToDoActionTypes.SuccessGetToDoAction;
  constructor(readonly payload: { toDos: IToDo[]}) {}
};

export class BeginCreateToDoAction implements Action {
  readonly type = ToDoActionTypes.BeginCreateToDoAction;
  constructor(readonly payload: {toDo : IToDo}) {}
};

export class SuccessCreateToDoAction implements Action {
  readonly type = ToDoActionTypes.SuccessCreateToDoAction;
  constructor(readonly payload: {toDo : IToDo}) {}
};

export class ErrorToDoAction implements Action {
  readonly type = ToDoActionTypes.ErrorToDoAction;
  constructor(readonly payload: {error : Error}) {}
};

// export type ActionsUnion = GetToDoAction | CreateToDoAction | BeginGetToDoAction | SuccessGetToDoAction | BeginCreateToDoAction | SuccessCreateToDoAction| ErrorToDoAction;
export type ActionsUnion = BeginGetToDoAction | SuccessGetToDoAction | BeginCreateToDoAction | SuccessCreateToDoAction| ErrorToDoAction;