export interface IToDo {
  title: string;
  isCompleted: boolean;
}
